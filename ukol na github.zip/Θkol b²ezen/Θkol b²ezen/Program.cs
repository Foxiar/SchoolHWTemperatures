﻿using Spectre.Console;
Dictionary<int, int> teplotyDny = new Dictionary<int, int>();
dalsiden:
var den = AnsiConsole.Ask<string>("Zadej den v měsící (od 1 do 31)[/]");


Console.WriteLine("Zadej teplotu pro den číslo " + den + ".");
int teplota = int.Parse(Console.ReadLine());
try
{
    teplotyDny.Add(int.Parse(den), teplota);
}
catch
{
    Console.WriteLine("Chybne data");
    goto dalsiden;
}

var pokracovani = AnsiConsole.Prompt(
    new SelectionPrompt<string>()
        .Title("[blue]Chceš zadat další den?[/]")
        .PageSize(3)
        .MoreChoicesText("[grey]Pro pohyb v menu používej šipky.[/]")
        .AddChoices(new[] {
            "Ano", "Ne"
        }));
if (pokracovani == "Ano")
{
    goto dalsiden;
}
else
{
    var vyhodnoceni = AnsiConsole.Prompt(
    new SelectionPrompt<string>()
        .Title("[blue]Jaké statistiky chceš zobrazit?[/]")
        .PageSize(3)
        .MoreChoicesText("[grey]Pro pohyb v menu používej šipky.[/]")
        .AddChoices(new[] {
            "Maximální teplotu", "Minimální teplotu", "Průměrnou teplotu"
        }));
}